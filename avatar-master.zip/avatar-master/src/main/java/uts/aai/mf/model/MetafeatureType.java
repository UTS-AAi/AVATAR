/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.aai.mf.model;

import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;

/**
 *
 * @author ntdun
 */
public enum MetafeatureType {
    QUALITY, ATTRIBUTE_TRANSFORMATION, CLASS_TRANSFORMATION
}
